﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using Auto_Ecole.Models;
using AutoEcole.Entities;
using AutoEcole.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using AutoEcole.Persistence;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace AutoEcole.Controllers
{
    public class AutoController : Controller
    {
        //public ApplicationException DbContext { get; }
        private readonly ILogger<AutoController>
            _logger; // readonly parce que c'est modifiable que dans le constructeur

        private readonly ApplicationDbContext _dbContext;
        private readonly IMapper _mapper;
        //private readonly INotyfService _notifyService;

        public AutoController(ILogger<AutoController> logger, ApplicationDbContext dbContext1 , IMapper mapper)
        {
            //DbContext = dbContext;
            _dbContext = dbContext1;
            _logger = logger;
            _mapper = mapper;
            // _notifyService = notifyService;
        }



        public IActionResult Inscription()
        {
            // on lui fornit les infos
            //var inscriptioninfo = _dbContext.Inscriptions.ToList();// = select* from Inscription 
            return View(_dbContext.Inscriptions
                 .Select(x => _mapper.Map<InscriptionViewModel>(x))
                .ToList());
            // return View(_dbContext.Inscriptions
            //  .Include(x => x.))
        }

        public IActionResult FicheInsciption()
        {
            return RedirectToAction("Edit");
        }

        public IActionResult Edit(Guid id)
        {
            Inscription inscription = null;
            if (id != Guid.Empty)
                inscription = _dbContext.Inscriptions.Find(id);
            inscription ??= new Inscription();
            var viewModel = _mapper.Map<InscriptionViewModel>(inscription); 
            /*viewModel.SliPersons = _dbContext.enseignants
            .Select(x => new SelectListItem(x.FullName, x.Id.ToString()))
            .ToList();*/
            return View(viewModel);
        

        }


        [HttpPost]
        public IActionResult Edit(InscriptionViewModel model)
        {
            _logger.LogTrace($"reçoit le model avec le gsm {model.Gsm}");
            //return Ok();
            Inscription inscription = null;
            if (model.Id != Guid.Empty)
                inscription = _dbContext.Inscriptions.Find(model.Id);

            inscription ??= new Inscription();
           // var inscription = _dbContext.Inscriptions.Find(model.Id) ?? new Inscription();
           //inscription ?? = new Inscription();
              //  inscription = model.Nom;
                //inscription = model.Prenom;
                //inscription = model.Gsm;
                //inscription = model.Mail;
                //inscription = model.DateInscription;
                
                _mapper.Map(model, inscription);
                _dbContext.Inscriptions.Update(inscription);
                //_dbContext.Update(inscription);
               //_dbContext.Add(inscription);
               _dbContext.SaveChanges();
               
            return RedirectToAction("Inscription");
        }
        
        public IActionResult Over(Guid Id)
        {

            Inscription inscription = null;
            if (Id != Guid.Empty)
                inscription = _dbContext.Inscriptions.Find(Id);
            if (inscription != null)
            {
                _dbContext.Remove(inscription);
                _dbContext.SaveChanges();
              
            }
            else
            {
                Console.Write("test");
            }
            return RedirectToAction("Inscription");
        }
        
        

        public IActionResult Error()
        {
            return View(new ErrorViewModel {RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier});
        }

    }
}

    

    
