using System;
using System.ComponentModel.DataAnnotations;

namespace AutoEcole.Entities
{
    public class Inscription
    {
      

        public Guid Id { get; set; }
       // [Required]// veux dire pas de  vide non null 
        public String Nom { get; set; }
        public String Prenom { get; set; }
        public String Gsm { get; set; }
        public String Mail { get; set; }
        public DateTime? DateInscription { get; set; }// le ? veux dire que la date peux être nulable 

    }
}