using AutoEcole.Entities;
using AutoEcole.Models;
using AutoMapper;

namespace AutoEcole.Configurations
{
    public class AutoMapper: Profile
    {
        public AutoMapper()
        {
            CreateMap<Inscription, InscriptionViewModel>().ReverseMap();
            
            // CreateMap<PcrTest, PcrTestViewModel>()
            //     .ForMember(x => x.ReceptionDateee, y => y.MapFrom(z => z.ReceptionDate))
            //     .ReverseMap()
            //     .ForMember(x => x.ReceptionDate, y => y.MapFrom(z => z.ReceptionDateee));
            // CreateMap<PcrTest, PcrTestViewModel>()
            //     .ForMember(x => x.Code, y => y.MapFrom(z => $"{z.Code}{z.Comment}"));
            
        }
        
    }
}