using System;
using System.ComponentModel.DataAnnotations;
using AutoEcole.Entities;
using Microsoft.AspNetCore.Mvc;

namespace AutoEcole.Models
{
    public class InscriptionViewModel
    {
        public Guid Id { get; set; }
       // public Guid id { get; set; }
        [Required(ErrorMessage = "Le champ 'nombre heur' est requis.")]
       // public string nbrheur { get; set; }
        public String Nom { get; set; }
        public String Prenom { get; set; }
        public String Gsm { get; set; }
        public String Mail { get; set; }
        public DateTime? DateInscription { get; set; }
        
        
    }
}