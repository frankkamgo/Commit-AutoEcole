using AutoEcole.Entities;
using Microsoft.EntityFrameworkCore;

namespace AutoEcole.Persistence
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        
        public DbSet<Inscription> Inscriptions { get; set; }
    }
}